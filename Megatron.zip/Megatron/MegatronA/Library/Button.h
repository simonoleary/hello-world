/*
 *  Button.h
 */
void button_init(void);

bool button_S1_pressed(void);

bool button_S2_pressed(void);
